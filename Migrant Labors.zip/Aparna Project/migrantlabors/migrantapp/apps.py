from django.apps import AppConfig


class MigrantappConfig(AppConfig):
    name = 'migrantapp'
